/**
 * 03_gumroad_ping_apps_script_autoresponder.gs
 * MIT License — Copyright (c) 2026 Trung Thanh Tran (https://github.com/Tthanh2k6)
 *
 * WHY THIS EXISTS (Bypassing Gumroad's $100 Workflow Gate on Day 0):
 * Gumroad disables native Emails & automated Workflows until your account has earned $100+
 * after fees AND received its first bank/PayPal payout. However, Gumroad's real-time "Ping"
 * webhook (Settings -> Advanced -> Ping) works from $0.00 on Day 0!
 *
 * DEPLOYMENT IN 3 MINUTES (100% Free on Google Workspace / Gmail):
 * 1. Create a blank Google Sheet -> Extensions -> Apps Script -> paste this file into Code.gs.
 * 2. Update CONFIG below (your name, starter permalink, and Pro upgrade link).
 * 3. Click Deploy -> New deployment -> Type: Web app -> Execute as: Me -> Who has access: Anyone.
 * 4. Copy the Web App URL into Gumroad -> Settings -> Advanced -> Ping endpoint.
 * 5. (Optional) Add a Daily Time-Driven Trigger in Apps Script pointing to `processScheduledNurtureEmails`
 *    to send Day-3 and Day-7 technical follow-ups automatically to free downloaders who haven't upgraded yet.
 */

const CONFIG = {
  SHEET_NAME: 'Gumroad_CRM_Ledger',
  STARTER_PERMALINK: 'python-hidden-api-starter-kit-lite',
  PRO_PERMALINK: 'python-ai-automation-n8n-scraper-toolkit-pro',
  PRO_UPGRADE_URL: 'https://trungthanh16.gumroad.com/l/python-ai-automation-n8n-scraper-toolkit-pro',
  SENDER_NAME: 'Trung Thanh Tran',
  DISCOUNT_CODE_DAY7: 'LITETOPRO25',
};

const HEADERS = [
  'ingested_at_iso',
  'sale_id_hash',
  'sale_id',
  'email',
  'full_name',
  'permalink',
  'price_usd',
  'currency',
  'license_key',
  'is_test',
  'refunded',
  'nurture_stage', // 'DAY0_SENT' | 'DAY3_SENT' | 'DAY7_SENT' | 'PRO_BUYER'
];

/**
 * Webhook receiver for Gumroad Ping (POST application/x-www-form-urlencoded).
 */
function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000); // Concurrency guard preventing overlapping webhook row collisions

  try {
    const params = (e && e.parameter) ? e.parameter : {};
    const email = String(params.email || '').trim().toLowerCase();
    const saleId = String(params.sale_id || params.order_id || Utilities.getUuid()).trim();
    const permalink = String(params.permalink || params.product_permalink || '').trim();
    const fullName = String(params.full_name || '').trim();
    const priceCents = Number(params.price || 0);
    const priceUsd = (priceCents / 100).toFixed(2);
    const currency = String(params.currency || 'usd').toUpperCase();
    const licenseKey = String(params.license_key || '').trim();
    const isTest = String(params.test || 'false').toLowerCase() === 'true';
    const refunded = String(params.refunded || 'false').toLowerCase() === 'true';

    if (!email) {
      return jsonResponse_({ ok: false, reason: 'missing_email' });
    }

    const sheet = getOrCreateLedgerSheet_();
    const saleHash = computeSha256Hex_(saleId + ':' + email + ':' + permalink).slice(0, 16);

    // Idempotency check: skip duplicate webhook retries
    if (hashExistsInColumn_(sheet, 2, saleHash)) {
      return jsonResponse_({ ok: true, deduplicated: true, sale_id_hash: saleHash });
    }

    const isPaidPro = priceCents > 0 || permalink === CONFIG.PRO_PERMALINK;
    let initialStage = isPaidPro ? 'PRO_BUYER' : 'PENDING';

    if (!refunded && !isPaidPro) {
      sendDay0QuickstartEmail_(email, fullName);
      initialStage = 'DAY0_SENT';
    }

    sheet.appendRow([
      new Date().toISOString(),
      saleHash,
      saleId,
      email,
      fullName,
      permalink,
      priceUsd,
      currency,
      licenseKey,
      isTest,
      refunded,
      initialStage,
    ]);

    return jsonResponse_({ ok: true, stage: initialStage, sale_id_hash: saleHash });
  } finally {
    lock.releaseLock();
  }
}

/**
 * Daily cron job (set a daily time-driven trigger) that sends Day-3 and Day-7 follow-ups
 * ONLY to free starter downloaders who have NOT purchased a paid Pro toolkit yet.
 */
function processScheduledNurtureEmails() {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(15000)) return;

  try {
    const sheet = getOrCreateLedgerSheet_();
    const values = sheet.getDataRange().getValues();
    if (values.length <= 1) return;

    // Build set of emails that already bought any paid product
    const paidBuyerEmails = new Set();
    for (let i = 1; i < values.length; i++) {
      const rowEmail = String(values[i][3] || '').toLowerCase();
      const rowPrice = Number(values[i][6] || 0);
      const rowStage = String(values[i][11] || '');
      if (rowPrice > 0 || rowStage === 'PRO_BUYER') {
        paidBuyerEmails.add(rowEmail);
      }
    }

    const nowMs = Date.now();
    const dayMs = 24 * 60 * 60 * 1000;
    let stageUpdates = 0;

    for (let i = 1; i < values.length; i++) {
      const ingestedIso = String(values[i][0] || '');
      const email = String(values[i][3] || '').toLowerCase();
      const fullName = String(values[i][4] || '');
      const refunded = Boolean(values[i][10]);
      const stage = String(values[i][11] || '');

      if (!email || refunded || paidBuyerEmails.has(email)) continue;

      const elapsedDays = (nowMs - new Date(ingestedIso).getTime()) / dayMs;
      if (stage === 'DAY0_SENT' && elapsedDays >= 3) {
        sendDay3ArchitectureEmail_(email, fullName);
        values[i][11] = 'DAY3_SENT';
        stageUpdates++;
      } else if (stage === 'DAY3_SENT' && elapsedDays >= 7) {
        sendDay7UpgradeOfferEmail_(email, fullName);
        values[i][11] = 'DAY7_SENT';
        stageUpdates++;
      }
    }

    // Batch write updated stages in one V8 memory call (prevents 6-minute timeouts)
    if (stageUpdates > 0) {
      sheet.getRange(1, 1, values.length, values[0].length).setValues(values);
    }
  } finally {
    lock.releaseLock();
  }
}

function sendDay0QuickstartEmail_(email, fullName) {
  const greeting = fullName ? 'Hey ' + fullName.split(' ')[0] : 'Hey there';
  const subject = '[Quickstart] Running your Schema.org & Hidden JSON Starter Kit in 60s';
  const body = [
    greeting + ',',
    '',
    'Thanks for downloading the Python Structured JSON-LD & DevTools XHR Starter Kit!',
    '',
    'To run the zero-dependency parser test right away:',
    '  python 02_public_schema_org_entity_parser.py --demo',
    '',
    'Make sure to check out 01_Hidden_JSON_API_vs_Headless_Architecture_Guide.md for the 4-layer inspection cascade that cuts worker memory from ~800MB to <35MB.',
    '',
    'If you run into any edge cases on your target stack, just hit reply to this email.',
    '',
    'Happy building,',
    CONFIG.SENDER_NAME,
  ].join('\n');

  MailApp.sendEmail({ to: email, subject: subject, body: body, name: CONFIG.SENDER_NAME });
}

function sendDay3ArchitectureEmail_(email, fullName) {
  const greeting = fullName ? 'Hey ' + fullName.split(' ')[0] : 'Hey there';
  const subject = 'Why single-layer web parsers & Google Sheets syncs fail in week 2';
  const body = [
    greeting + ',',
    '',
    'Quick engineering follow-up on the starter kit you grabbed earlier this week:',
    '',
    'When teams move from a quick script to recurring production pipelines, two failure modes usually hit first:',
    '1. Pages without JSON-LD needing automatic fallback to SSR state -> HTML <table> matrices -> DOM cards.',
    '2. Concurrent webhooks calling appendRow() without LockService or batch 2D setValues(), triggering 6-minute timeouts.',
    '',
    'If you ever need all 6 production CLI engines (4-Tier Extractor, Catalog Diff Engine, PDF Invoice Math Parser, V8 Apps Script Suite, API Resilience Patches) + 3 ready-to-import n8n/Make JSON blueprints, you can inspect the full Pro Toolkit here:',
    CONFIG.PRO_UPGRADE_URL,
    '',
    'Cheers,',
    CONFIG.SENDER_NAME,
  ].join('\n');

  MailApp.sendEmail({ to: email, subject: subject, body: body, name: CONFIG.SENDER_NAME });
}

function sendDay7UpgradeOfferEmail_(email, fullName) {
  const greeting = fullName ? 'Hey ' + fullName.split(' ')[0] : 'Hey there';
  const subject = 'Skip 20+ hours of Python extractor, PDF parser & n8n boilerplate';
  const body = [
    greeting + ',',
    '',
    'Hope the open-core starter files saved you some debugging time this week!',
    '',
    'Whenever you need the complete 6-engine Python 3.11+ CLI suite + 3 ready-to-import n8n & Make.com JSON blueprints + multi-sheet styled Excel (.xlsx) exporters, you can upgrade to the Pro Toolkit here:',
    CONFIG.PRO_UPGRADE_URL,
    '',
    'Everything is 100% clean source code with zero vendor lock-in.',
    '',
    'Best,',
    CONFIG.SENDER_NAME,
  ].join('\n');

  MailApp.sendEmail({ to: email, subject: subject, body: body, name: CONFIG.SENDER_NAME });
}

function getOrCreateLedgerSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(CONFIG.SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(CONFIG.SHEET_NAME);
    sheet.appendRow(HEADERS);
    sheet.setFrozenRows(1);
  }
  return sheet;
}

function hashExistsInColumn_(sheet, colIndex1Based, targetHash) {
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return false;
  const colValues = sheet.getRange(2, colIndex1Based, lastRow - 1, 1).getValues();
  for (let i = 0; i < colValues.length; i++) {
    if (String(colValues[i][0]) === targetHash) return true;
  }
  return false;
}

function computeSha256Hex_(input) {
  const digest = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, input, Utilities.Charset.UTF_8);
  return digest.map(function (b) {
    const v = (b < 0 ? b + 256 : b).toString(16);
    return v.length === 1 ? '0' + v : v;
  }).join('');
}

function jsonResponse_(payload) {
  return ContentService
    .createTextOutput(JSON.stringify(payload))
    .setMimeType(ContentService.MimeType.JSON);
}
