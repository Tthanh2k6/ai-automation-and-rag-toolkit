#!/usr/bin/env python3
"""
02_public_schema_org_entity_parser.py
MIT License — Copyright (c) 2026 Trung Thanh Tran (https://github.com/Tthanh2k6)

Zero-dependency Python 3.10+ CLI utility for extracting public structured metadata:
  1. Schema.org JSON-LD (<script type="application/ld+json">), including nested @graph arrays
  2. OpenGraph (og:*) & Twitter Card meta tags
  3. Canonical link, page title, and meta description

Quick Verification (No external packages required):
    python 02_public_schema_org_entity_parser.py --demo
    python 02_public_schema_org_entity_parser.py --url "https://example.com" --json-out entity.json
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from typing import Any


DEMO_HTML_DOCUMENT = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Nordic Cloud Systems — Enterprise Data & Automation Platform</title>
  <meta name="description" content="Deterministic workflow orchestration and analytics infrastructure for B2B engineering teams." />
  <link rel="canonical" href="https://nordiccloud.example.com/products/workflow-core" />
  <meta property="og:title" content="Nordic Cloud Workflow Core v4.2" />
  <meta property="og:type" content="product" />
  <meta property="og:url" content="https://nordiccloud.example.com/products/workflow-core" />
  <meta property="og:site_name" content="Nordic Cloud Systems" />
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Organization",
        "name": "Nordic Cloud Systems AB",
        "url": "https://nordiccloud.example.com",
        "sameAs": [
          "https://github.com/nordiccloud-example",
          "https://www.linkedin.com/company/nordiccloud-example"
        ]
      },
      {
        "@type": "SoftwareApplication",
        "name": "Workflow Core Enterprise CLI",
        "applicationCategory": "DeveloperApplication",
        "operatingSystem": "Linux, macOS, Windows",
        "softwareVersion": "4.2.0",
        "offers": {
          "@type": "Offer",
          "price": "49.00",
          "priceCurrency": "USD",
          "availability": "https://schema.org/InStock"
        },
        "aggregateRating": {
          "@type": "AggregateRating",
          "ratingValue": "4.9",
          "reviewCount": "128"
        }
      }
    ]
  }
  </script>
</head>
<body>
  <h1>Nordic Cloud Workflow Core</h1>
</body>
</html>
"""


class PublicMetadataHTMLParser(HTMLParser):
    """Lightweight streaming HTML parser capturing JSON-LD scripts, meta tags, and canonical links."""

    def __init__(self) -> None:
        super().__init__()
        self.in_title: bool = False
        self.in_jsonld: bool = False
        self._title_chunks: list[str] = []
        self._current_jsonld_chunks: list[str] = []
        self.raw_jsonld_blocks: list[str] = []
        self.meta_tags: dict[str, str] = {}
        self.canonical_url: str = ""

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attr_map = {k.lower(): (v or "").strip() for k, v in attrs}
        tag_lower = tag.lower()

        if tag_lower == "title":
            self.in_title = True
        elif tag_lower == "script" and "application/ld+json" in attr_map.get("type", "").lower():
            self.in_jsonld = True
            self._current_jsonld_chunks = []
        elif tag_lower == "meta":
            key = attr_map.get("property") or attr_map.get("name")
            content = attr_map.get("content", "")
            if key and content and key not in self.meta_tags:
                self.meta_tags[key] = content
        elif tag_lower == "link":
            rel = attr_map.get("rel", "").lower()
            href = attr_map.get("href", "")
            if "canonical" in rel and href and not self.canonical_url:
                self.canonical_url = href

    def handle_data(self, data: str) -> None:
        if self.in_title:
            self._title_chunks.append(data)
        if self.in_jsonld:
            self._current_jsonld_chunks.append(data)

    def handle_endtag(self, tag: str) -> None:
        tag_lower = tag.lower()
        if tag_lower == "title":
            self.in_title = False
        elif tag_lower == "script" and self.in_jsonld:
            self.in_jsonld = False
            block = "".join(self._current_jsonld_chunks).strip()
            if block:
                self.raw_jsonld_blocks.append(block)

    @property
    def page_title(self) -> str:
        return " ".join("".join(self._title_chunks).split())


def flatten_jsonld_entities(node: Any) -> list[dict[str, Any]]:
    """Recursively unwraps top-level arrays and Schema.org @graph containers into flat entity dicts."""
    entities: list[dict[str, Any]] = []
    if isinstance(node, list):
        for item in node:
            entities.extend(flatten_jsonld_entities(item))
    elif isinstance(node, dict):
        if "@graph" in node and isinstance(node["@graph"], list):
            entities.extend(flatten_jsonld_entities(node["@graph"]))
        else:
            entities.append(node)
    return entities


def normalize_entity_summary(entity: dict[str, Any], fallback_url: str) -> dict[str, Any]:
    """Maps common Schema.org fields into a clean flat dictionary ready for CSV/JSON export."""
    raw_type = entity.get("@type", "Thing")
    entity_type = ", ".join(raw_type) if isinstance(raw_type, list) else str(raw_type)
    name = str(entity.get("name") or entity.get("headline") or "").strip()
    url = str(entity.get("url") or fallback_url).strip()

    offers = entity.get("offers")
    if isinstance(offers, list) and offers:
        offers = offers[0]
    price = ""
    currency = ""
    availability = ""
    if isinstance(offers, dict):
        price = str(offers.get("price", offers.get("lowPrice", "")))
        currency = str(offers.get("priceCurrency", ""))
        availability = str(offers.get("availability", "")).rsplit("/", 1)[-1]

    rating_obj = entity.get("aggregateRating")
    rating_value = ""
    review_count = ""
    if isinstance(rating_obj, dict):
        rating_value = str(rating_obj.get("ratingValue", ""))
        review_count = str(rating_obj.get("reviewCount", rating_obj.get("ratingCount", "")))

    idempotency_seed = f"{url}|{entity_type}|{name}".encode("utf-8")
    entity_hash = hashlib.sha256(idempotency_seed).hexdigest()[:16]

    return {
        "entity_sha256_id": entity_hash,
        "schema_type": entity_type,
        "name": name,
        "url": url,
        "price": price,
        "currency": currency,
        "availability": availability,
        "rating_value": rating_value,
        "review_count": review_count,
    }


def parse_html_metadata(html_text: str, source_url: str = "") -> dict[str, Any]:
    """Parses full structured metadata from an HTML string."""
    parser = PublicMetadataHTMLParser()
    parser.feed(html_text)

    parsed_entities: list[dict[str, Any]] = []
    parse_errors: int = 0
    for raw_block in parser.raw_jsonld_blocks:
        try:
            loaded = json.loads(raw_block)
            parsed_entities.extend(flatten_jsonld_entities(loaded))
        except json.JSONDecodeError:
            parse_errors += 1

    canonical = parser.canonical_url or parser.meta_tags.get("og:url") or source_url
    normalized_rows = [normalize_entity_summary(ent, canonical) for ent in parsed_entities]

    return {
        "extracted_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_url": source_url or canonical,
        "canonical_url": canonical,
        "page_title": parser.page_title,
        "meta_description": parser.meta_tags.get("description") or parser.meta_tags.get("og:description", ""),
        "opengraph": {k: v for k, v in parser.meta_tags.items() if k.startswith("og:")},
        "jsonld_block_count": len(parser.raw_jsonld_blocks),
        "jsonld_parse_errors": parse_errors,
        "entities_normalized": normalized_rows,
        "entities_raw": parsed_entities,
    }


def fetch_public_html(url: str, timeout_sec: int = 15) -> str:
    """Fetches a public webpage using standard HTTP headers."""
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": "PublicSchemaMetadataReader/1.0 (+https://github.com/Tthanh2k6)",
            "Accept": "text/html,application/xhtml+xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
        },
    )
    with urllib.request.urlopen(req, timeout=timeout_sec) as resp:
        charset = resp.headers.get_content_charset() or "utf-8"
        return resp.read().decode(charset, errors="replace")


def export_csv(rows: list[dict[str, Any]], csv_path: Path) -> None:
    """Writes normalized Schema.org entities to UTF-8 CSV."""
    fieldnames = [
        "entity_sha256_id",
        "schema_type",
        "name",
        "url",
        "price",
        "currency",
        "availability",
        "rating_value",
        "review_count",
    ]
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with csv_path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")

    argp = argparse.ArgumentParser(
        description="Extract Schema.org JSON-LD & OpenGraph metadata from public webpages."
    )
    argp.add_argument("--url", help="Public webpage URL to inspect")
    argp.add_argument("--html-file", help="Path to a local .html file to parse")
    argp.add_argument("--demo", action="store_true", help="Run built-in self-test demo HTML")
    argp.add_argument("--json-out", help="Optional path to save full JSON output")
    argp.add_argument("--csv-out", help="Optional path to save normalized entities CSV")
    args = argp.parse_args()

    if args.demo:
        html_content = DEMO_HTML_DOCUMENT
        src = "https://nordiccloud.example.com/products/workflow-core"
    elif args.html_file:
        fpath = Path(args.html_file)
        html_content = fpath.read_text(encoding="utf-8", errors="replace")
        src = fpath.as_uri()
    elif args.url:
        try:
            html_content = fetch_public_html(args.url)
        except urllib.error.URLError as exc:
            print(f"[ERROR] Failed to fetch URL {args.url}: {exc}", file=sys.stderr)
            return 1
        src = args.url
    else:
        argp.print_help()
        print("\nTip: Run with `--demo` to test immediately without network calls.")
        return 0

    result = parse_html_metadata(html_content, source_url=src)

    print(f"Page Title     : {result['page_title']}")
    print(f"Canonical URL  : {result['canonical_url']}")
    print(f"JSON-LD Blocks : {result['jsonld_block_count']} (Entities flattened: {len(result['entities_normalized'])})")
    for idx, ent in enumerate(result["entities_normalized"], start=1):
        price_str = f" | {ent['price']} {ent['currency']}" if ent["price"] else ""
        rating_str = f" | {ent['rating_value']}/5 ({ent['review_count']} reviews)" if ent["rating_value"] else ""
        print(f"  [{idx}] [{ent['schema_type']}] {ent['name']} (ID: {ent['entity_sha256_id']}){price_str}{rating_str}")

    if args.json_out:
        out_p = Path(args.json_out)
        out_p.parent.mkdir(parents=True, exist_ok=True)
        out_p.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"Saved JSON -> {out_p}")

    if args.csv_out:
        csv_p = Path(args.csv_out)
        export_csv(result["entities_normalized"], csv_p)
        print(f"Saved CSV  -> {csv_p}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
