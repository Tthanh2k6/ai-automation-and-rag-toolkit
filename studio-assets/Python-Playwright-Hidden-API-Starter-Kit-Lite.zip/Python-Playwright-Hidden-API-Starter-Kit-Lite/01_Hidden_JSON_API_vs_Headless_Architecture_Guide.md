# Architecture Field Guide: Structured JSON-LD, Hydration State & Public XHR Endpoints vs. Heavy Headless Browsers

**Edition:** 2026 Open-Core Starter Manual (MIT Reference)  
**Author:** Trung Thanh Tran (`github.com/Tthanh2k6`)

---

## 1. Why 80% of Headless Browser Pipelines Collapse Under Production Load

When tasked with ingesting public product catalogs, business directories, or documentation feeds, the default instinct is often to launch a full headless browser (`Chromium` / `Firefox`) for every single URL and query fragile CSS class selectors like `.css-1dbjc4n > div:nth-child(3)`.

In production, that approach introduces three compounding failure modes:

| Metric / Failure Mode | Full Headless Browser + CSS Selectors | Structured Metadata (`JSON-LD` / SSR State / Public JSON API) |
| :--- | :--- | :--- |
| **RAM Footprint per Worker** | `450 MB – 950 MB` per Chromium context | **`18 MB – 35 MB`** (Pure HTTP stream + JSON parser) |
| **Median Latency per Page** | `3,200 ms – 8,500 ms` (JS bundle + hydration + fonts) | **`120 ms – 380 ms`** (`10x–25x` faster wall-clock throughput) |
| **Frontend Redesign Resilience** | Breaks every time Tailwind/CSS hashes recompile | **Deterministic** (`Schema.org` SEO specs rarely change) |
| **Data Type Fidelity** | Everything arrives as raw strings (`"$1,299.00 *"`) | Native typed numbers, ISO-8601 timestamps, nested SKU arrays |

> **Core Engineering Principle:** Modern e-commerce storefronts, SaaS directories, and content platforms actively want search engines and AI indexers to understand their public pages. Before launching a single headless browser tab, inspect the structured machine-readable layers the server is *already* handing you in plain sight.

---

## 2. The 4-Layer Deterministic Inspection Cascade

Always evaluate public web documents from the lightest, highest-signal layer down to the heaviest:

```text
[Layer 1: Embedded Schema.org JSON-LD (<script type="application/ld+json">)]
       │  (Empty or partial?)
       ▼
[Layer 2: SSR Framework Hydration State (__NEXT_DATA__, __NUXT__, Apollo State)]
       │  (Client-fetched SPA?)
       ▼
[Layer 3: Public Read-Only XHR / Fetch JSON Endpoints (DevTools -> Network -> Fetch/XHR)]
       │  (Server-rendered legacy HTML only?)
       ▼
[Layer 4: Normalized Semantic HTML <table> Grids & Scoped Playwright Response Listeners]
```

### Layer 1: `application/ld+json` (`Schema.org` Entities)
For Google Rich Results compliance, millions of public storefronts and business directories embed complete structured JSON objects inside `<script type="application/ld+json">` tags right inside `<head>`.
- **Common `@type` schemas:** `Product`, `AggregateOffer`, `Organization`, `LocalBusiness`, `SoftwareApplication`, `FAQPage`, `Article`, `ItemList`.
- **Edge Case #1 (`@graph` Arrays):** WordPress/Yoast, Shopify themes, and enterprise CMS platforms frequently wrap multiple entities inside `{"@context": "https://schema.org", "@graph": [...]}` or emit a top-level JSON list `[...]` rather than a single dict. Always recursively flatten `@graph` and list roots.
- **Edge Case #2 (Trailing Commas / HTML Entities):** Some templates render unescaped newlines inside JSON-LD blocks; strip surrounding whitespace before `json.loads()` and isolate parser exceptions per `<script>` block so one malformed widget never aborts the rest of the page.
- *Run the companion script `02_public_schema_org_entity_parser.py --demo` included in this kit to see full `@graph` flattening + OpenGraph fusion in action.*

### Layer 2: SSR Hydration Payloads (`__NEXT_DATA__`)
Next.js, Nuxt, Remix, and Astro sites pre-render initial props into a single JSON script tag so React/Vue can hydrate client-side without re-fetching:

```python
import json
import re

NEXT_DATA_RE = re.compile(
    r'<script[^>]+id=["\']__NEXT_DATA__["\'][^>]*>(.*?)</script>',
    re.DOTALL | re.IGNORECASE,
)

def extract_nextjs_page_props(html_text: str) -> dict:
    match = NEXT_DATA_RE.search(html_text)
    if not match:
        return {}
    payload = json.loads(match.group(1).strip())
    return payload.get("props", {}).get("pageProps", {})
```

### Layer 3: Inspecting Public `Fetch/XHR` JSON Feeds in Chrome DevTools (60-Second Workflow)
When a public catalog paginates dynamically or filters items without reloading the URL:
1. Open Chrome DevTools (`F12` or `Ctrl+Shift+I`) -> switch to the **`Network`** tab.
2. Click the **`Fetch/XHR`** filter pill (hiding noisy `.js`, `.css`, `.woff2`, and `.png` requests).
3. Check **`Preserve log`**, then trigger pagination (e.g., click *Page 2* or change sort order).
4. Sort requests by **`Size`** or scan **`Type: json`** responses. Click **`Preview`** to inspect clean JSON arrays (`items`, `results`, `edges`, `total_count`, `next_cursor`).
5. Right-click the clean public JSON request -> **`Copy as cURL (bash)`** -> strip unnecessary analytics cookies to identify the minimal clean `Accept: application/json` query parameters (`?page=2&limit=50`).

### Layer 4: When You *Must* Use Playwright — Capture Network JSON, Not DOM Pixels
If an application requires client-side session initialization before firing its public XHR call, **do not** parse brittle DOM classes afterward. Attach an event-driven response listener AND abort heavy visual assets (`image`, `media`, `font`) to cut bandwidth by ~75%:

```python
import asyncio
from playwright.async_api import async_playwright

async def capture_public_xhr_json(target_url: str, api_path_fragment: str = "/api/catalog"):
    captured_payloads = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context()

        # Skip heavy visual media while keeping scripts & XHR intact
        await context.route(
            "**/*",
            lambda route: route.abort()
            if route.request.resource_type in {"image", "media", "font"}
            else route.continue_(),
        )

        page = await context.new_page()

        async def handle_response(response):
            if api_path_fragment in response.url and response.status == 200:
                ctype = response.headers.get("content-type", "")
                if "application/json" in ctype:
                    captured_payloads.append(await response.json())

        page.on("response", handle_response)
        await page.goto(target_url, wait_until="networkidle", timeout=20000)
        await browser.close()

    return captured_payloads
```

---

## 3. Production Compliance & Reliability Checklist

Always design public data ingestion pipelines as polite, good-citizen HTTP clients:
1. **Respect `robots.txt` & Terms of Service:** Check `/robots.txt` rules and never target private, login-walled, or personal user data.
2. **Enforce Concurrency Caps & `Retry-After` Headers:** Bound async workers with `asyncio.Semaphore(3)` to `5` and honor HTTP `429 Retry-After` headers using exponential backoff with full jitter.
3. **Deterministic Idempotency Keys (`SHA-256`):** Hash `(canonical_url + sku_or_entity_id)` before writing to PostgreSQL, Google Sheets, or Excel so re-running a job never creates duplicate rows.

---

## Next Step: Run the Included Code Modules

1. **Test Zero-Dependency Schema.org + OpenGraph Extraction:**
   ```bash
   python 02_public_schema_org_entity_parser.py --demo
   ```
2. **Deploy Your Own Zero-Cost Gumroad Webhook CRM + Autoresponder:**
   Open `03_gumroad_ping_apps_script_autoresponder.gs` to wire instant Google Sheets logging and automated Day-0 / Day-3 / Day-7 follow-up emails directly from `Gumroad Ping`.
3. **Need All 6 Production CLI Engines + 3 Importable `n8n` / `Make.com` JSON Blueprints?**
   See `04_UPGRADE_TO_PRO_TOOLKIT.md` for a side-by-side module comparison.
