# Open-Core Starter Kit (MIT) vs. Complete Pro Engineering Toolkit (`$14.99`)

Thank you for downloading the **Open-Core Starter Kit (`$0+`)**! Every script in this starter package is MIT-licensed and yours to keep, modify, and ship in personal or commercial projects forever.

> **Did this free starter kit save you 30 minutes today?**  
> Leaving a quick **`★★★★★` (5-Star) rating** on your Gumroad download page takes 3 seconds and helps keep these open-core engineering guides free for the developer community!

---

## When Should You Upgrade to the Complete Pro Toolkit?

The Lite Starter Kit gives you the foundational **Layer 1 (`Schema.org` JSON-LD + OpenGraph) parser** and **Gumroad Ping Apps Script CRM**.

When your project needs **4-tier fallback extraction, supplier catalog price/stock diffing, deterministic PDF invoice reconciliation, multi-sheet styled Excel (`.xlsx`) workbooks, and ready-to-import `n8n` / `Make.com` JSON workflows**, upgrading saves you **20+ hours** of plumbing from scratch:

| Engineering Capability | Lite Starter Kit (Included Here — `$0+` MIT) | Complete Toolkit Pro (`$14.99` Instant `.ZIP`) |
| :--- | :---: | :---: |
| **Architecture Guide: JSON-LD / SSR / XHR vs. Headless RAM** | ✅ | ✅ |
| **Tier 1 (`application/ld+json` + OpenGraph) Parser** | ✅ (`02_public_schema_org_entity_parser.py`) | ✅ (`universal_web_extractor.py`) |
| **Tier 2 (HTML `<table>` Grids) & Tier 3 (`__NEXT_DATA__` + DOM Cards)** | ❌ | ✅ |
| **Multi-Sheet Styled `.xlsx` Workbook + High-DPI Preview `.png`** | ❌ | ✅ (`sample-factory/` included) |
| **Catalog Deduplication & Price/Stock Delta Diff Engine** | ❌ | ✅ (`data_diff_and_cleaner_poc.py`) |
| **Deterministic PDF Commercial Invoice Parser (`Qty * Price == Total`)** | ❌ | ✅ (`pdf_and_document_parser_poc.py`) |
| **Concurrency-Safe V8 Google Apps Script Generator (5 Templates)** | 1 CRM Autoresponder | ✅ Full 5-Pattern Suite (`google_apps_script_generator.py`) |
| **Production API Resilience Suite (OpenAI Truncation, HMAC, Async Backoff)** | ❌ | ✅ (`api_bugfix_diagnostic_generator.py`) |
| **n8n & Make.com Blueprint Compiler + 3 Ready-to-Import `.JSON` Files** | ❌ | ✅ (`workflows/` + `n8n_make_workflow_generator.py`) |

---

## Instant Access to the Complete Pro Toolkit (`$14.99`)

👉 **Upgrade here:**  
**[https://trungthanh16.gumroad.com/l/python-ai-automation-n8n-scraper-toolkit-pro](https://trungthanh16.gumroad.com/l/python-ai-automation-n8n-scraper-toolkit-pro)**

- **100% Clean Python 3.11+ & V8 Source Code** — Zero obfuscation, zero recurring subscription lock-in.
- **Unified Master CLI (`arsenal_cli.py`)** — Run demos, generate `.json` workflows, or parse files from one command line.
- **14-Day Hassle-Free Refund Guarantee** — Reply to your receipt email anytime within 14 days if it doesn't fit your stack.

---

## More Open-Source Repos, Actors & Engineering Articles by Trung Thanh Tran

- **GitHub (Hybrid RAG, FastAPI Structured Outputs & Supabase RLS):** [https://github.com/Tthanh2k6/ai-automation-and-rag-toolkit](https://github.com/Tthanh2k6/ai-automation-and-rag-toolkit)
- **Cloud Production Actors (Apify Store):** [https://apify.com/thanh81646](https://apify.com/thanh81646)
- **Technical Deep-Dives (DEV Community):** [https://dev.to/tthanh2k6](https://dev.to/tthanh2k6)
